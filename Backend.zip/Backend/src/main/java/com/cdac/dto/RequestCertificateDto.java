package com.cdac.dto;

import lombok.Data;

@Data
public class RequestCertificateDto {
	
	private String name;
		
	private String issuer;
	
	private String certificateName;
	
}
	