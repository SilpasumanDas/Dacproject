package com.cdac.dto;

import lombok.Data;

@Data
public class ForgotPasswordDto {
	
	private Long id;
	
	private String password;

}
